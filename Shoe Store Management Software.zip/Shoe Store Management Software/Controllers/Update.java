package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class Update {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Button backButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Button updateButton;
    @FXML
    private TextField oldNameField;
    @FXML
    private TextField oldPriceField;
    @FXML
    private TextField newNameField;
    @FXML
    private TextField newPriceField;


    public void moveToDashboard(ActionEvent event) throws IOException {
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/FXMLs/Dashboard.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
        scene.getStylesheets().add(css);
        stage.setMaximized(true);
        stage.setFullScreen(true);
        stage.show();
    }

    public void logout(ActionEvent event) throws IOException {
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/FXMLs/LogIn.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
        scene.getStylesheets().add(css);
        stage.setMaximized(true);
        stage.setFullScreen(true);
        stage.show();
    }

    public void updateProduct(ActionEvent event) throws IOException {

        if (Objects.equals(oldNameField.getText(), "") || Objects.equals(oldPriceField.getText(), "") || Objects.equals(newNameField.getText(), "") || Objects.equals(newPriceField.getText(), ""))
        {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Field/s Empty");
            alert.setHeaderText("Field/s can't be empty");
            alert.showAndWait();

        }else {

            if(Objects.equals("Product: "+oldNameField.getText()+"-"+oldPriceField.getText(), FileHandling.readProductsFromFile(oldNameField.getText()+"-"+oldPriceField.getText())))
            {

                FileHandling.writeProductsInFile("Product: " + newNameField.getText() + "-" + newPriceField.getText());

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Updated");
                alert.setHeaderText("Product updated successfully!");
                alert.showAndWait();

                oldNameField.setText("");
                oldPriceField.setText("");
                newNameField.setText("");
                newPriceField.setText("");


            }else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Not Found");
                alert.setHeaderText("Can't find the relevant product");
                alert.showAndWait();

                oldNameField.setText("");
                oldPriceField.setText("");
                newNameField.setText("");
                newPriceField.setText("");
            }
        }

    }
}
