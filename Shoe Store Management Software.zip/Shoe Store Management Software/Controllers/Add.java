package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class Add {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Button backButton;
    @FXML
    private Button addButton;
    @FXML
    private Button logoutButton;
    @FXML
    private TextField nameField;
    @FXML
    private TextField priceField;

    public void moveToDashboard(ActionEvent event) throws IOException {
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/FXMLs/Dashboard.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
        scene.getStylesheets().add(css);
        stage.setMaximized(true);
        stage.setFullScreen(true);
        stage.show();
    }

    public void addProduct(ActionEvent event) throws IOException {

        if(nameField.getText() == "" || priceField.getText() == "")
        {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Empty Field/s");
            alert.setHeaderText("Fields can't be empty!");
            alert.showAndWait();

        }else {

            FileHandling.writeProductsInFile("Product: " + nameField.getText() + "-" + priceField.getText());

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setHeaderText("Product added successfully!");
            alert.showAndWait();

            nameField.setText("");
            priceField.setText("");
        }

    }

    public void logout(ActionEvent event) throws IOException {
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/FXMLs/LogIn.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
        scene.getStylesheets().add(css);
        stage.setMaximized(true);
        stage.setFullScreen(true);
        stage.show();
    }
}
