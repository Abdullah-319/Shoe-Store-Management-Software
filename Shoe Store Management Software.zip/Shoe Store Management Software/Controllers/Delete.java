package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.util.Objects;

public class Delete {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Button backButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Button deleteButton;
    @FXML
    private Button viewButton;
    @FXML
    private TextArea viewArea;
    @FXML
    private TextField nameField;
    @FXML
    private TextField priceField;

    public void moveToDashboard(ActionEvent event) throws IOException {
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/FXMLs/Dashboard.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
        scene.getStylesheets().add(css);
        stage.setMaximized(true);
        stage.setFullScreen(true);
        stage.show();
    }

    public void logout(ActionEvent event) throws IOException {
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/FXMLs/LogIn.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
        scene.getStylesheets().add(css);
        stage.setMaximized(true);
        stage.setFullScreen(true);
        stage.show();
    }

    public void deleteProducts(ActionEvent event) throws IOException {

        if (Objects.equals(nameField.getText(), ""))
        {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Field Empty");
            alert.setHeaderText("Name can't be empty");
            alert.showAndWait();

        }else {

            if (("Product: " + nameField.getText() + "-" + priceField.getText()).equals(FileHandling.readProductsFromFile(nameField.getText() + "-" + priceField.getText())))
            {
                FileHandling.writeProductsInFile("Deleted");

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Deleted");
                alert.setHeaderText("Product deleted successfully!");
                alert.showAndWait();

                nameField.setText("");
                priceField.setText("");

                viewArea.setText(FileHandling.readProductsFromFile("Deleted"));

            }else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Not Found");
                alert.setHeaderText("Can't find the relevant product");
                alert.showAndWait();
            }
        }

    }

    public void view(ActionEvent event) throws IOException {
        viewArea.setText(FileHandling.readProductsFromFile("Product:"));
    }
}
