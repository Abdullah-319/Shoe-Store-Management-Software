package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Objects;

public class View {
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Button backButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Button viewButton;
    @FXML
    private TextArea viewArea;

    public void moveToDashboard(ActionEvent event) throws IOException {
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/FXMLs/Dashboard.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
        scene.getStylesheets().add(css);
        stage.setMaximized(true);
        stage.setFullScreen(true);
        stage.show();
    }

    public void logout(ActionEvent event) throws IOException {
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/FXMLs/LogIn.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
        scene.getStylesheets().add(css);
        stage.setMaximized(true);
        stage.setFullScreen(true);
        stage.show();
    }

    public void viewProducts(ActionEvent event) throws IOException {
        //System.out.println("Products shown");

        viewArea.setText(FileHandling.readProductsFromFile("Product:"));
    }
}
