package Controllers;

import java.io.*;

public class FileHandling {
    public static void writeAdminInFile(String input) throws IOException {
        // Creating the file
        File file = new File("Essentials/admin.txt");
        FileWriter fw = new FileWriter(file);
        BufferedWriter bw = new BufferedWriter(fw);

        bw.write(input);
        bw.newLine();
        bw.close();
        fw.close();
    }

    public static String readAdminFromFile(String contain) throws IOException {
        File file = new File("Essentials/admin.txt");
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);

        String[] data = new String[100];
        String out = "";
        int counter = 0;

        /*
        while ((data[counter] = br.readLine())!=null)
        {
            //data[counter]= br.readLine();
            if(data[counter]!=null)
            {
//                System.out.println(data[counter]);
                if (data[counter].contains(contain))
                {
                    //System.out.println(data[counter]);
                    out[counter] = data[counter];
                }
            }

            counter++;
        }*/



        while ((data[counter] = br.readLine())!=null)
        {
            if(data[counter]!=null)
            {
                if (data[counter].contains(contain))
                {
                    out= data[counter];
                }
            }

            counter++;
        }


        br.close();
        fr.close();

        return out;
    }

    public static void writeProductsInFile(String input) throws IOException {
        // Creating the file
        File file = new File("Essentials/products.txt");
        FileWriter fw = new FileWriter(file);
        BufferedWriter bw = new BufferedWriter(fw);

        bw.write(input);
        bw.newLine();
        bw.close();
        fw.close();
    }


    public static String readProductsFromFile(String contain) throws IOException {
        File file = new File("Essentials/products.txt");
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);

        String[] data = new String[100];
        String out = "";
        int counter = 0;


        while ((data[counter] = br.readLine())!=null)
        {
            //data[counter]= br.readLine();
            if(data[counter]!=null)
            {
//                System.out.println(data[counter]);
                if (data[counter].contains(contain))
                {
                    //System.out.println(data[counter]);
                    out = data[counter];
                }
            }

            counter++;
        }


        br.close();
        fr.close();

        return out;
    }
}
