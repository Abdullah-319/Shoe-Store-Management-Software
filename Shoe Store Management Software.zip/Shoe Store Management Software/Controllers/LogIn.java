package Controllers;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class LogIn {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Button signupButton;
    @FXML
    private Button submitLoginButton;
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;

    public void switchToSignupPage(ActionEvent event) throws IOException {
        root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/FXMLs/SignUp.fxml")));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
        scene.getStylesheets().add(css);
        stage.setMaximized(true);
        stage.setFullScreen(true);
        stage.show();
    }

    public void login(ActionEvent event) throws IOException {

        if(usernameField.getText() == "" || passwordField.getText() == "")
        {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Empty Field/s");
            alert.setHeaderText("Fields can't be empty!");
            alert.showAndWait();

        }else {

            //System.out.println(usernameField.getText()+"-"+passwordField.getText());
            //System.out.println(FileHandling.readAdminFromFile(usernameField.getText()+"-"+passwordField.getText()));

            if((usernameField.getText() + "-" + passwordField.getText()).equals(FileHandling.readAdminFromFile(usernameField.getText() + "-" + passwordField.getText())))
            {
                root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/FXMLs/Dashboard.fxml")));
                stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
                scene.getStylesheets().add(css);
                stage.setMaximized(true);
                stage.setFullScreen(true);
                stage.show();

            }else {
                Alert alert= new Alert(Alert.AlertType.ERROR);
                alert.setTitle("User Not Found");
                alert.setHeaderText("Credentials are incorrect");
                alert.showAndWait();

                usernameField.setText("");
                passwordField.setText("");
            }

        }

    }


}
