import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.util.Objects;

public class App extends Application {

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) {

        try {
            // Setting up the essentials
            Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("FXMLs/SignUp.fxml")));
            stage.setTitle("Oxfords of Boston");
            Scene scene = new Scene(root);
            Image logo = new Image("/Essentials/logo.jpg");
            stage.getIcons().add(logo);

            // Setting up the CSS file
            String css = Objects.requireNonNull(this.getClass().getResource("/CSS/HomePage.css")).toExternalForm();
            scene.getStylesheets().add(css);



            // Setting up the scene & showing the stage
            stage.setScene(scene);
            stage.setMaximized(true);
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
